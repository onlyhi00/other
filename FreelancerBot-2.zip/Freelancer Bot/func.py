from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.keys import Keys
from time import sleep
from datetime import datetime
import json
import random
import os

def find_element(driver: webdriver.Chrome, whichBy, unique: str) -> WebElement:
    sleep(0.5)
    while True:
        try:
            element = driver.find_element(whichBy, unique)
            break
        except:
            sleep(0.5)
    return element

def find_elements(driver: webdriver.Chrome, whichBy, unique: str) -> list[WebElement]:
    sleep(0.5)
    while True:
        try:
            elements = driver.find_elements(whichBy, unique)
            break
        except:
            sleep(0.5)
    return elements

def generate_profile():

    with open('users.json', 'r') as file:
        users = json.load(file)
    firstname = users['name'][random.randint(0, 9)]['firstName']
    lastname = users['name'][random.randint(0, 9)]['lastName']
    address = users["address"][random.randint(0,9)]

    with open('last-index.txt', 'r') as lastIndex:
        email_index = int(lastIndex.read()) + 1
    with open('last-index.txt', 'w') as lastIndex:
        lastIndex.write(str(email_index))
    username = firstname.lower() + str(email_index)
    email = firstname.lower() + lastname.lower() + str(email_index)
    password = 'pwd123!@#'
    hourly_rate = random.randint(20, 35)
    current_datetime = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    profile = {"firstname" : firstname, "lastname" : lastname, "username" : username, "email" : email + "@outlook.com", "password" : password, "address" : address, "country" : "Finland", "hourly_rate" : hourly_rate, "status" : "Only info", "date" : current_datetime}

    print(profile)
    return profile

def create_profile(count):
    for i in range(count):
        profile = generate_profile()
        if not os.path.exists('accounts.json'):
            with open('accounts.json', 'w') as file:
                json.dump([], file)
        with open('accounts.json', 'r') as file:
            accounts = json.load(file)
        accounts.append(profile)
        with open('accounts.json', 'w') as file:
            json.dump(accounts, file)
    print("{} profiles were created.\n Please create email.".format(count))

def create_email(driver, profile):
    
    outlook_url = "https://outlook.live.com/mail/about/index_en.html"
    email = profile['email']
    email = email.replace("@outlook.com", "")
    password = profile['password']
    firstname = profile['firstname']
    lastname = profile["lastname"]
    country = profile['country']

    year = random.randint(1992, 1996)
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    birth_month = months[random.randint(0, 11)]
    birth_day = random.randint(0, 28)

    driver.get(outlook_url)
    find_elements(driver, By.CLASS_NAME, 'action')[0].click()
    find_element(driver, By.ID, 'usernameInput').send_keys(email)
    find_element(driver, By.CSS_SELECTOR, 'button[type="submit"]').click()
    find_element(driver, By.ID, 'Password').send_keys(password)
    find_element(driver, By.ID, 'nextButton').click()
    find_element(driver, By.ID, 'firstNameInput').send_keys(firstname)
    find_element(driver, By.ID, 'lastNameInput').send_keys(lastname)
    find_element(driver, By.ID, 'nextButton').click()
    Select(find_element(driver, By.ID, 'countryRegionDropdown')).select_by_visible_text(country)
    Select(find_element(driver, By.ID, 'BirthMonth')).select_by_visible_text(birth_month)
    Select(find_element(driver, By.ID, 'BirthDay')).select_by_visible_text(str(birth_day))
    find_element(driver, By.ID, 'BirthYear').send_keys(year)
    find_element(driver, By.ID, 'nextButton').click()
    # Pass the bot test
    find_element(driver, By.ID, "acceptButton").click()

    profile['status'] = "Email"
    if not os.path.exists('accounts.json'):
        with open('accounts.json', 'w') as file:
            json.dump([], file)
    with open('accounts.json', 'r') as file:
        accounts = json.load(file)
    accounts.append(profile)
    with open('accounts.json', 'w') as file:
        json.dump(accounts, file)

    while True:
        response = input("Ready?(y/n): ")
        if response == "y":
            break
        sleep(0.5)
    print("Successfully created!")

def create_freelancer(driver, mode):
    sleep(3)
    if mode == "y":
        driver.switch_to.active_element.send_keys(Keys.CONTROL, 't')
        sleep(1)
        driver.execute_script("window.open('https://www.freelancer.com/signup', '_blank');")
        sleep(1)
        driver.switch_to.window(driver.window_handles[1])
    else:
        driver.get('https://www.freelancer.com/signup')

    with open('accounts.json', 'r') as file:
        accounts = json.load(file)
    if mode == "y":
        index0 = len(accounts) - 1
    else:
        for i in range(len(accounts)):
            if accounts[i]["status"] == 'Email':
                index0 = i
                break

    print("Selected index: {}".format(index0))
    account = accounts[index0]
    print(account)
    email = account["email"]
    password = account["password"]
    firstname = account["firstname"]
    lastname = account["lastname"]
    username = account["username"]
    address = account["address"]
    hourly_rate = account["hourly_rate"]

    find_element(driver, By.CSS_SELECTOR, 'input[aria-label="First Name"]').send_keys(firstname)
    find_element(driver, By.CSS_SELECTOR, 'input[aria-label="Last Name"]').send_keys(lastname)
    find_element(driver, By.CSS_SELECTOR, 'input[aria-label="Email"]').send_keys(email)
    find_element(driver, By.CSS_SELECTOR, 'input[aria-label="Password"]').send_keys(password)
    find_element(driver, By.XPATH, '/html/body/app-root/app-logged-out-shell/div/app-signup-page/div/div[1]/app-signup/app-details-form/form/fl-bit/fl-label/fl-text/span/label/fl-text/div').click()
    find_element(driver, By.CSS_SELECTOR, 'button[type="submit"]').click()
    find_element(driver, By.CSS_SELECTOR, 'input[placeholder="Username"]').send_keys(username)
    find_element(driver, By.CSS_SELECTOR, 'button[type="submit"]').click()
    find_element(driver, By.CSS_SELECTOR, 'img[alt="Work illustration"]').click()
    find_element(driver, By.CSS_SELECTOR, 'label[for="PrivacyConsent"]').click()
    find_element(driver, By.CSS_SELECTOR, 'label[for="PersonalUse"]').click()
    find_element(driver, By.CSS_SELECTOR, 'button[type="submit"]').click()
    print("Successfully signed up!")

    find_element(driver, By.CSS_SELECTOR, 'div[data-name="ui-computer-outline"]').click()
    skills = find_elements(driver, By.CSS_SELECTOR, 'div[data-name="ui-plus-thin"]')
    skill_counter = 0
    for skill in skills:
        skill.click()
        sleep(0.5)
        skill_counter += 1
        if skill_counter == 20:
            break
    find_element(driver, By.XPATH, '/html/body/app-root/app-logged-in-shell/div/fl-container/div/div/ng-component/fl-bit/app-freelancer-onboarding-skills/fl-container/fl-skills/div/div[3]/fl-button/button').click()
    find_element(driver, By.XPATH, '/html/body/app-root/app-logged-in-shell/div/fl-container/div/div/ng-component/fl-bit/app-freelancer-onboarding-linked-accounts/fl-container/fl-bit/fl-bit[2]/fl-bit/fl-link/button').click()
    find_element(driver, By.CSS_SELECTOR, 'button[data-color="secondary"]').click()
    find_element(driver, By.ID, 'inputHeadline').send_keys("Software Engineer")
    overview = "Experienced Full Stack Developer with a passion for creating innovative web solutions. Proficient in a wide range of technologies and frameworks, with a focus on delivering high-quality, user-centric applications. Strong problem-solving skills and a collaborative mindset to drive project success."
    find_element(driver, By.TAG_NAME, 'textarea').send_keys(overview)
    find_element(driver, By.XPATH, '/html/body/app-root/app-logged-in-shell/div/fl-container/div/div/ng-component/fl-bit/ng-component/fl-container/fl-bit/ng-component/fl-bit/app-freelancer-onboarding-profile-details-footer/fl-bit/div/fl-button/button').click()
    language = find_element(driver, By.CLASS_NAME, 'RawInput')
    language.send_keys("English")
    language.send_keys(Keys.ENTER)
    year = random.randint(1992, 1996)
    find_element(driver, By.ID, 'inputBirthdate').send_keys("06/17/{}".format(year))
    next_button = find_element(driver, By.XPATH, '/html/body/app-root/app-logged-in-shell/div/fl-container/div/div/ng-component/fl-bit/ng-component/fl-container/fl-bit/ng-component/fl-bit/app-freelancer-onboarding-profile-details-footer/fl-bit/div/fl-button/button')
    driver.execute_script("arguments[0].click();", next_button)
    sleep(5)
    print("Sent email")

    if mode == "y":
        driver.switch_to.window(driver.window_handles[0])
        sleep(3)
        element = find_element(driver, By.CSS_SELECTOR, 'span[title="noreply@freelancer.com"]')
        driver.execute_script("arguments[0].click();", element)
        while True:
            try:
                verify_link = find_elements(driver, By.CSS_SELECTOR, 'a[data-auth="NotApplicable"]')[1].get_attribute("href")
                break
            except:
                sleep(1)
        print(verify_link)
        driver.switch_to.window(driver.window_handles[1])
    else:
        verify_link = input("Please input verify link: ")
    sleep(1)
    driver.get(verify_link)
    find_element(driver, By.CSS_SELECTOR, 'button[data-underline="never"]').click()
    
    accounts[index0]["status"] = "Complete"
    with open('accounts.json', 'w') as file:
        json.dump(accounts, file)

    driver.get('https://www.freelancer.com/search/projects')
    find_element(driver, By.XPATH, '/html/body/app-root/app-logged-in-shell/div/fl-container/div/div/app-search/app-search-projects/div/fl-container/div/div[2]/app-search-results/fl-card/div/div[2]/app-search-results-projects/div/a[1]/fl-project-contest-card/div[1]/div[1]/div[1]/fl-heading/h2').click()
    find_element(driver, By.ID, 'hourly-rate').send_keys(hourly_rate)
    find_element(driver, By.CSS_SELECTOR, 'input[placeholder="Enter your address"]').send_keys(address)
    driver.switch_to.active_element.send_keys(Keys.DOWN)
    driver.switch_to.active_element.send_keys(Keys.ENTER)

    while True:
        response = input("Complete profile?(y/n): ")
        if response == "y":
            break
        sleep(1)
    print("Successfully verified!")

def delete_history(driver, mode):
    if mode == "y":
        sleep(5)
        driver.close()
        driver.switch_to.window(driver.window_handles[0])
        sleep(1)
        driver.get("chrome://settings/clearBrowserData")
        sleep(3)
        driver.switch_to.active_element.send_keys(Keys.TAB)
        sleep(0.3)
        driver.switch_to.active_element.send_keys(Keys.ENTER)
        sleep(5)
    else:
        sleep(5)
        driver.get("chrome://settings/clearBrowserData")
        sleep(3)
        driver.switch_to.active_element.send_keys(Keys.TAB)
        sleep(0.3)
        driver.switch_to.active_element.send_keys(Keys.ENTER)
        sleep(5)
    print("Deleted history.")
