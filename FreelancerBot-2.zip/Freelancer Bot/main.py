from selenium import webdriver
import func

if __name__ == "__main__":

    response1 = input("Do you want to create emails?(y/n): ")
    response2 = input("Do you want to create freelancer accounts?(y/n): ")
    count = int(input("How many?: "))

    if response1 == 'y' and response2 == 'n':
        func.create_profile(count)
    if response2 == 'y':
        remote_debugging_address = "127.0.0.1:9224"
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_experimental_option("debuggerAddress", remote_debugging_address)
        driver = webdriver.Chrome(options=chrome_options)
    
        for i in range(count):
            if i != 0:
                func.delete_history(driver, response1)
            if response1 == 'y':
                profile = func.generate_profile()
                func.create_email(driver, profile)
            func.create_freelancer(driver, response1)
            print("Success!")
        